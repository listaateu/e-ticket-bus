<?php
/**
 * ============================================================
 * FILE         : sopir/function/komponen_kartu_jadwal.php
 * FUNGSI       : Komponen: kartu satu jadwal (rute, jam, bus, progres penumpang naik, tombol Manifest & Scan).
 * DIPANGGIL DARI: pages/beranda/beranda.php, pages/jadwal/jadwal.php
 * ============================================================
 */

/** true bila bus sudah lewat jam berangkat dan tidak ada penumpang lunas (dewasa maupun bayi) */
function jadwal_dibatalkan(array $j): bool
{
    return !empty($j['sudah_berangkat'])
        && (int) $j['total_dewasa'] === 0
        && (int) $j['total_bayi'] === 0;
}

/** Label status jadwal: [kelas badge bootstrap, teks] */
function status_jadwal(array $j): array
{
    // Sudah lewat jam berangkat tapi tidak ada satu pun penumpang lunas = jadwal dianggap DIBATALKAN
    // (tidak ada yang bisa membayar lagi setelah berangkat). Status ini dihitung otomatis, tidak disimpan di database.
    if (jadwal_dibatalkan($j)) {
        return ['danger', 'Dibatalkan'];
    }
    if (!empty($j['sudah_tiba'])) {
        return ['dark', 'Selesai'];
    }
    if (!empty($j['sudah_berangkat'])) {
        return ['info text-dark', 'Dalam perjalanan'];
    }
    return ['success', 'Akan berangkat'];
}

function komponen_kartu_jadwal(array $j): void
{
    [$kelas_status, $label_status] = status_jadwal($j);
    $selesai = !empty($j['sudah_tiba']);
    // Tidak ada penumpang LUNAS sama sekali. Kalau bus sudah berangkat, tidak akan ada lagi yang bisa membayar
    // (admin tidak bisa menyetujui pembayaran setelah berangkat), jadi manifest & scan tidak ada gunanya.
    $tanpa_penumpang = jadwal_dibatalkan($j);
    $kode_st = $tanpa_penumpang ? 'batal' : (!empty($j['sudah_tiba']) ? 'selesai' : (!empty($j['sudah_berangkat']) ? 'jalan' : 'akan'));
    ?>
    <div class="kartu-jadwal st-<?= $kode_st ?><?= ($selesai || $tanpa_penumpang) ? ' selesai' : '' ?>">
      <div class="row align-items-center gy-3">
        <div class="col-lg-4">
          <div class="d-flex align-items-center gap-2 mb-2">
            <span class="badge bg-<?= $kelas_status ?> status-badge"><?= e($label_status) ?></span>
            <small class="text-muted">Jadwal #<?= (int) $j['id'] ?></small>
          </div>
          <div class="rute"><?= e($j['kota_asal']) ?> <i class="bi bi-arrow-right mx-1"></i> <?= e($j['kota_tujuan']) ?></div>
          <div class="waktu">
            <i class="bi bi-calendar-event"></i><?= e(tanggal_indo($j['jam_berangkat'])) ?>
            <?php if (!empty($j['jam_tiba'])): ?><span>&middot; tiba <?= e(jam($j['jam_tiba'])) ?></span><?php endif; ?>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="bus-wrap">
            <div class="bus-ikon"><i class="fa-solid fa-bus"></i></div>
            <div>
              <div class="bus-nama"><?= e($j['nama_bus']) ?> &middot; <?= e($j['kelas']) ?></div>
              <div class="bus-meta"><?= e($j['plat_nomor']) ?> &middot; <?= (int) $j['kapasitas_kursi'] ?> kursi</div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <?php if ($tanpa_penumpang): ?>
            <div class="tanpa-penumpang">
              <strong>Tidak ada penumpang</strong>
              Tidak ada pemesanan lunas sampai jam berangkat, jadwal dibatalkan.
            </div>
          <?php else: ?>
            <?php komponen_progress_naik((int) $j['total_naik'], (int) $j['total_dewasa']); ?>
          <?php endif; ?>
          <?php if ((int) $j['total_bayi'] > 0): ?>
            <small class="text-muted"><i class="bi bi-person-arms-up"></i> + <?= (int) $j['total_bayi'] ?> bayi</small>
          <?php endif; ?>
        </div>
        <div class="col-lg-2 d-grid gap-2">
          <?php if ($tanpa_penumpang): ?>
            <span class="btn btn-outline-secondary btn-sm disabled" aria-disabled="true" title="Tidak ada penumpang di jadwal ini"><i class="bi bi-list-check me-1"></i>Manifest</span>
          <?php else: ?>
            <a href="<?= url('manifest', ['id' => $j['id']]) ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-list-check me-1"></i>Manifest</a>
          <?php endif; ?>
          <?php if (!$selesai && !$tanpa_penumpang): ?>
            <a href="<?= url('scan', ['id' => $j['id']]) ?>" class="btn btn-primary btn-sm"><i class="bi bi-qr-code-scan me-1"></i>Scan Tiket</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
<?php }