<?php
defined('ADMIN_APP') || exit('Akses langsung tidak diizinkan.');   // hanya boleh dibuka lewat index.php
// admin/pages/data_pemesanan/data_pemesanan.php
// Tabel Data Pemesanan (Read): semua booking + status pembayarannya, dengan filter & pencarian.

include_once __DIR__ . '/../../database/koneksi.php';
include_once __DIR__ . '/../../components/pagination.php';
include_once __DIR__ . '/../../components/pencarian.php';

// ===== Status pembayaran (sama dengan payments.status). 'belum' = booking belum punya data pembayaran =====
$STATUS = [
    'belum'   => ['label' => 'Belum Bayar', 'badge' => 'pending'],
    'pending' => ['label' => 'Menunggu',    'badge' => 'pending'],
    'lunas'   => ['label' => 'Lunas',       'badge' => 'success'],
    'ditolak' => ['label' => 'Ditolak',     'badge' => 'failed'],
];
// ================================================================================

$filter = param_enum('status', array_keys($STATUS));   // hanya nilai dari daftar resmi
$cari   = param_cari();                                 // dari kotak cari di topbar (?q=), teks biasa, maksimal 100 karakter

// Bagian FROM dipakai bersama oleh ringkasan & tabel.
// Ambil pembayaran TERBARU per booking supaya satu booking tidak muncul dobel.
$dari = "FROM bookings b
         JOIN users     u ON u.id = b.user_id
         JOIN schedules s ON s.id = b.schedule_id
         JOIN buses    bs ON bs.id = s.bus_id
         LEFT JOIN payments p ON p.id = (SELECT MAX(id) FROM payments WHERE booking_id = b.id)";
$status_sql = "COALESCE(p.status, 'belum')";

// Kolom yang dicari: kode booking, penumpang, rute, bus, plat, kelas, sopir, kursi, metode, status, total, jam berangkat
$label_sql = 'CASE ' . $status_sql;                            // tulisan status yang tampil: "Belum Bayar", "Menunggu", dst.
foreach ($STATUS as $kode => $x) { $label_sql .= " WHEN '$kode' THEN '" . $x['label'] . "'"; }
$label_sql .= ' END';
$kolom_cari = ['b.kode_booking', 'u.nama', 'u.email', 's.kota_asal', 's.kota_tujuan', 'bs.nama_bus', 'bs.plat_nomor', "REPLACE(bs.plat_nomor, ' ', '')", 'bs.kelas', 's.sopir', 'b.nomor_kursi', 'p.metode_pembayaran', $status_sql, $label_sql, 'CAST(s.harga * b.jumlah_dewasa AS CHAR)', "DATE_FORMAT(s.jam_berangkat, '%d %b %Y, %H:%i')", "DATE_FORMAT(s.jam_berangkat, '%Y-%m-%d %H:%i')"];

// ---------- Ringkasan ----------
$hitung = ['' => 0, 'belum' => 0, 'pending' => 0, 'lunas' => 0, 'ditolak' => 0];
$pendapatan = 0;
$q = $koneksi->query("SELECT $status_sql AS st, COUNT(*) AS jml, SUM(s.harga * b.jumlah_dewasa) AS rupiah $dari GROUP BY st");
while ($r = $q->fetch_assoc()) {
    if (isset($hitung[$r['st']])) { $hitung[$r['st']] = (int) $r['jml']; }
    $hitung[''] += (int) $r['jml'];
    if ($r['st'] === 'lunas') { $pendapatan = (int) $r['rupiah']; }
}

// ---------- Jumlah di tombol filter (ikut pencarian; kartu ringkasan di atas tetap total keseluruhan) ----------
$hitung_tab = ['' => 0, 'belum' => 0, 'pending' => 0, 'lunas' => 0, 'ditolak' => 0];
$tipe_t  = '';
$param_t = [];
$syarat_t = syarat_cari($kolom_cari, $cari, $tipe_t, $param_t);
$st_tab = $koneksi->prepare("SELECT $status_sql AS st, COUNT(*) AS jml $dari WHERE 1=1 $syarat_t GROUP BY st");
if ($tipe_t !== '') { $st_tab->bind_param($tipe_t, ...$param_t); }
$st_tab->execute();
$q_tab = $st_tab->get_result();
while ($r = $q_tab->fetch_assoc()) {
    if (isset($hitung_tab[$r['st']])) { $hitung_tab[$r['st']] = (int) $r['jml']; }
    $hitung_tab[''] += (int) $r['jml'];
}

// ---------- Syarat filter + cari (dipakai untuk COUNT dan untuk tabel) ----------
$where = " WHERE 1=1";
$tipe  = '';
$param = [];
if ($filter !== '') {
    $where .= " AND $status_sql = ?";
    $tipe .= 's'; $param[] = $filter;
}
$where .= syarat_cari($kolom_cari, $cari, $tipe, $param);   // pencarian (?q=): tiap kata harus cocok dengan salah satu kolom

// ---------- Hitung total hasil (ikut filter & cari) untuk pagination ----------
$stmt_total = $koneksi->prepare("SELECT COUNT(*) AS t $dari $where");
if ($tipe !== '') { $stmt_total->bind_param($tipe, ...$param); }
$stmt_total->execute();
$total = (int) $stmt_total->get_result()->fetch_assoc()['t'];
[$per_halaman, $offset] = paginasi($total);

// ---------- Tabel: ambil 10 baris untuk halaman yang dibuka ----------
$sql = "SELECT b.id, b.kode_booking, b.nomor_kursi, b.jumlah_dewasa, b.jumlah_bayi,
               u.nama, s.kota_asal, s.kota_tujuan, s.jam_berangkat, s.harga * b.jumlah_dewasa AS harga,
               bs.plat_nomor, bs.kelas, b.batas_bayar,
               p.metode_pembayaran, $status_sql AS status_bayar
        $dari $where
        ORDER BY b.id DESC
        LIMIT ? OFFSET ?";

$stmt = $koneksi->prepare($sql);
$tipe .= 'ii'; $param[] = (int) $per_halaman; $param[] = (int) $offset;
$stmt->bind_param($tipe, ...$param);
$stmt->execute();
$hasil = $stmt->get_result();

$pesan = $_GET['pesan'] ?? '';
$url   = BASE_URL . '/admin/index.php?page=data_pemesanan';
$url_q = $cari !== '' ? '&q=' . urlencode($cari) : '';
$url_reset = $url . ($filter !== '' ? '&status=' . $filter : '');   // alamat tanpa pencarian
?>
<!-- style tombol filter aktif (boleh dipindah ke file CSS admin nanti) -->
<style>
  .table-filter-group .btn-table-action.active {
    background: #B94E77;      /* samakan dengan warna tombol "Tambah" */
    border-color: #B94E77;
    color: #fff;
    font-weight: 600;
  }
</style>

<!-- page header -->
<div class="page-header">
  <div>
    <h1 class="page-title">Data Pemesanan</h1>
    <p class="page-subtitle">Pantau semua tiket yang dipesan penumpang beserta status pembayarannya.</p>
  </div>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/admin/index.php" class="text-decoration-none text-muted-green">Dashboard</a></li>
      <li class="breadcrumb-item text-muted-green">Transaksi</li>
      <li class="breadcrumb-item active text-main" aria-current="page">Data Pemesanan</li>
    </ol>
  </nav>
</div>
<!-- page header -->

<?php if ($pesan === 'hapus_ok') : ?>
  <div class="alert alert-success">Pemesanan berhasil dibatalkan. Kursi bisa dipesan lagi.</div>
<?php elseif ($pesan === 'sudah_lunas') : ?>
  <div class="alert alert-danger">Pemesanan yang sudah lunas tidak bisa dibatalkan.</div>
<?php elseif ($pesan === 'gagal') : ?>
  <div class="alert alert-danger">Pemesanan gagal dibatalkan. Coba lagi.</div>
<?php endif; ?>

<!-- ringkasan -->
<div class="row g-3 mb-4">
  <div class="col-6 col-lg-3">
    <div class="card border-light shadow-sm p-3">
      <div class="text-muted small">Total Pemesanan</div>
      <div class="fs-4 fw-bold"><?= $hitung[''] ?></div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card border-light shadow-sm p-3">
      <div class="text-muted small">Menunggu Verifikasi</div>
      <div class="fs-4 fw-bold"><?= $hitung['pending'] ?></div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card border-light shadow-sm p-3">
      <div class="text-muted small">Lunas</div>
      <div class="fs-4 fw-bold"><?= $hitung['lunas'] ?></div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card border-light shadow-sm p-3">
      <div class="text-muted small">Pendapatan (Lunas)</div>
      <div class="fs-4 fw-bold">Rp <?= number_format($pendapatan, 0, ',', '.') ?></div>
    </div>
  </div>
</div>
<!-- ringkasan -->

<!-- kartu tabel -->
<div class="table-card-custom">

  <!-- bar atas tabel: filter status -->
  <div class="table-header-control">
    <div class="table-pagination-info">Menampilkan: <strong><?= $total ?></strong> pemesanan</div>
    <div class="table-filter-group">
      <a href="<?= $url . $url_q ?>" class="btn-table-action<?= $filter === '' ? ' active' : '' ?>">Semua (<?= $hitung_tab[''] ?>)</a>
      <?php foreach ($STATUS as $kode => $info) : ?>
        <a href="<?= $url ?>&status=<?= $kode ?><?= $url_q ?>" class="btn-table-action<?= $filter === $kode ? ' active' : '' ?>"><?= $info['label'] ?> (<?= $hitung_tab[$kode] ?>)</a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- info pencarian (kotak cari ada di topbar, sama seperti halaman lain) -->
  <?php render_info_cari($cari, $total, $url_reset); ?>

  <!-- tabel -->
  <div class="table-responsive">
    <table class="table-custom">
      <thead>
        <tr>
          <th>No</th>
          <th>Kode Booking</th>
          <th>Penumpang</th>
          <th>Rute</th>
          <th>Berangkat</th>
          <th>Bus</th>
          <th>Kursi</th>
          <th>Total</th>
          <th>Status Bayar</th>
          <th class="text-center">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($total === 0) : ?>
          <tr>
            <td colspan="10" class="text-center"><?= $cari !== '' ? 'Tidak ada pemesanan yang cocok dengan pencarian.' : 'Belum ada data pemesanan.' ?></td>
          </tr>
        <?php endif; ?>

        <?php $no = $offset + 1; while ($b = $hasil->fetch_assoc()) :
          $info = $STATUS[$b['status_bayar']] ?? ['label' => $b['status_bayar'], 'badge' => 'pending'];
        ?>
          <tr>
            <td><?= $no++ ?></td>
            <td class="table-order-id"><?= htmlspecialchars($b['kode_booking']) ?></td>
            <td><?= htmlspecialchars($b['nama']) ?></td>
            <td><?= htmlspecialchars($b['kota_asal']) ?> <i class="bi bi-arrow-right mx-1"></i> <?= htmlspecialchars($b['kota_tujuan']) ?></td>
            <td><?= date('d M Y, H:i', strtotime($b['jam_berangkat'])) ?></td>
            <td><?= htmlspecialchars($b['plat_nomor']) ?> <span class="badge-table success"><?= htmlspecialchars($b['kelas']) ?></span></td>
            <td><?= htmlspecialchars($b['nomor_kursi']) ?><br><small class="text-muted"><?= (int) $b['jumlah_dewasa'] ?> dewasa<?= (int) $b['jumlah_bayi'] > 0 ? ', ' . (int) $b['jumlah_bayi'] . ' bayi' : '' ?></small></td>
            <td>Rp <?= number_format((int) $b['harga'], 0, ',', '.') ?></td>
            <td>
              <span class="badge-table <?= $info['badge'] ?>"><?= htmlspecialchars($info['label']) ?></span>
              <?php if (!empty($b['batas_bayar']) && in_array($b['status_bayar'], ['belum', 'ditolak'], true)) : ?>
                <br><small class="text-muted">Batas bayar: <?= date('d M, H:i', strtotime($b['batas_bayar'])) ?></small>
              <?php endif; ?>
            </td>
            <td>
              <div class="d-flex justify-content-center gap-1">
                <a href="<?= $url ?>&aksi=detail&id=<?= (int) $b['id'] ?>" class="table-btn-action" title="Lihat detail"><i class="bi bi-eye"></i></a>
                <?php if ($b['status_bayar'] !== 'lunas') : ?>
                  <form action="<?= BASE_URL ?>/admin/function/data_pemesanan.php?aksi=hapus" method="post" class="d-inline"
                        onsubmit="return confirm('Batalkan pemesanan <?= htmlspecialchars($b['kode_booking'], ENT_QUOTES) ?>?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                    <button type="submit" class="table-btn-action delete" title="Batalkan pemesanan"><i class="bi bi-trash"></i></button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <!-- tombol halaman (muncul hanya kalau data lebih dari 10) -->
  <?php render_pagination($total); ?>

</div>
<!-- kartu tabel -->